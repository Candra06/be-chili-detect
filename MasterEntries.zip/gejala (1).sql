-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 02, 2025 at 03:12 PM
-- Server version: 8.0.28
-- PHP Version: 8.1.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_spk_cabai`
--

-- --------------------------------------------------------

--
-- Table structure for table `gejala`
--

CREATE TABLE `gejala` (
  `id` int UNSIGNED NOT NULL,
  `kode_gejala` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gejala` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `densitas` double NOT NULL,
  `bagian` enum('Batang','Akar','Daun','Bunga','Buah') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` enum('Show','Deleted') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Show'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gejala`
--

INSERT INTO `gejala` (`id`, `kode_gejala`, `gejala`, `densitas`, `bagian`, `created_at`, `updated_at`, `status`) VALUES
(1, 'G1', 'Terdapat serangga kecil berwarna hitam memanjang pada bagian bawah daun muda', 0.3, 'Batang', '2025-01-24 02:35:14', '2025-01-24 02:38:48', 'Show'),
(2, 'G2', 'Daun keriting, mengkerut dan melengkung ke atas', 0.4, 'Batang', '2025-01-24 02:47:52', '2025-01-24 02:47:52', 'Show'),
(3, 'G3', 'Daun berwarna perak dan mudah rontok', 0.2, 'Batang', '2025-01-24 02:48:14', '2025-01-24 02:48:14', 'Show'),
(4, 'G4', 'Bunga cabai rontok', 0.1, 'Batang', '2025-01-24 02:48:37', '2025-01-24 02:48:37', 'Show'),
(5, 'G5', 'Terdapat serangga kecil berwarna kuning atau merah pada bagian bawah daun muda', 0.2, 'Batang', '2025-01-24 02:49:10', '2025-01-24 02:49:10', 'Show'),
(6, 'G6', 'Daun muda keriting dan melengkung atau menggulung ke bawah, serta menebal berbentuk seperti sendok terbalik', 0.4, 'Batang', '2025-01-24 02:49:29', '2025-01-24 02:49:29', 'Show'),
(7, 'G7', 'Daun cabai yang terserang berwarna kecoklatan keriting, dan mengecil', 0.3, 'Batang', '2025-01-24 02:49:56', '2025-01-24 02:49:56', 'Show'),
(8, 'G8', 'Bunga cabai menguning dan rontok', 0.1, 'Batang', '2025-01-24 02:50:29', '2025-01-24 02:50:29', 'Show'),
(9, 'G9', 'Terdapat serangga yang bergerombol di bawah permukaan daun, tepi daun ataupun batang', 0.2, 'Batang', '2025-01-24 02:51:11', '2025-01-24 02:51:11', 'Show'),
(10, 'G10', 'Terdapat banyak semut bergerombol pada batang tanaman cabai', 0.4, 'Batang', '2025-01-24 02:51:42', '2025-01-24 02:51:42', 'Show'),
(11, 'G11', 'Daun yang terserang berwarna hitam, pertumbuhan terhambat, keriting dan pertumbuhan tidak normal', 0.4, 'Batang', '2025-01-24 02:52:43', '2025-01-24 02:52:43', 'Show'),
(12, 'G12', 'Pucuk daun menjadi berubah menjadi kuning terang', 0.4, 'Batang', '2025-01-24 02:53:08', '2025-01-24 02:53:08', 'Show'),
(13, 'G13', 'Tulang daun menebal serta daun menggulung keatas', 0.4, 'Batang', '2025-01-24 02:53:28', '2025-01-24 02:53:28', 'Show'),
(14, 'G14', 'Tanaman cabai menjadi kerdil dan potensi buah berkurang', 0.2, 'Batang', '2025-01-24 02:53:47', '2025-01-24 02:53:47', 'Show'),
(15, 'G15', 'Terdapat bercak kering berwarna kecoklatan pada buah', 0.4, 'Batang', '2025-01-24 02:54:15', '2025-01-24 02:54:15', 'Show'),
(16, 'G16', 'Buah berubah menjadi berwarna kuning dan mengering', 0.4, 'Batang', '2025-01-24 02:54:35', '2025-01-24 02:54:35', 'Show'),
(17, 'G17', 'Warna kulit buah berubah menjadi seperti jerami padi', 0.2, 'Batang', '2025-01-24 02:54:56', '2025-01-24 02:54:56', 'Show'),
(18, 'G18', 'Daun mengalami kelayuan', 0.2, 'Batang', '2025-01-24 02:55:24', '2025-01-24 02:55:24', 'Show'),
(19, 'G19', 'Daun menguning dan menjalar ke ranting', 0.2, 'Batang', '2025-01-24 02:55:43', '2025-01-24 02:55:43', 'Show'),
(20, 'G20', 'Warna jaringan akar dan batang menjadi coklat dan terdapat benang-benang putih halus', 0.6, 'Batang', '2025-01-24 02:56:12', '2025-01-24 02:56:12', 'Show'),
(21, 'G21', 'Jika batang dipotong dan dimasukkan kedalam air jernih terdapat cairan putih', 0.6, 'Batang', '2025-01-24 02:56:44', '2025-01-24 02:56:44', 'Show'),
(22, 'G22', 'Daun habis dan tinggal tulang daun', 0.3, 'Batang', '2025-01-24 02:57:05', '2025-01-24 02:57:05', 'Show'),
(23, 'G23', 'Adanya lubang pada buah akibat ulat', 0.2, 'Batang', '2025-01-24 02:57:37', '2025-01-24 02:57:37', 'Show'),
(24, 'G24', 'Terdapat ulat pada daun', 0.5, 'Batang', '2025-01-24 02:58:01', '2025-01-24 02:58:01', 'Show'),
(25, 'G25', 'Terdapat bintik hitam pada buah cabai', 0.2, 'Batang', '2025-01-24 02:58:29', '2025-01-24 02:58:29', 'Show'),
(26, 'G26', 'Buah cabai rontok dan didalamnya terdapat belatung kecil', 0.6, 'Batang', '2025-01-24 02:58:47', '2025-01-24 02:58:47', 'Show'),
(27, 'G27', 'Buah cabai seperti berisi air', 0.2, 'Batang', '2025-01-24 02:59:05', '2025-01-24 03:08:06', 'Show');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gejala`
--
ALTER TABLE `gejala`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gejala`
--
ALTER TABLE `gejala`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
