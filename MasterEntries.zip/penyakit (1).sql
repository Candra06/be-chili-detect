-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 02, 2025 at 03:12 PM
-- Server version: 8.0.28
-- PHP Version: 8.1.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_spk_cabai`
--

-- --------------------------------------------------------

--
-- Table structure for table `penyakit`
--

CREATE TABLE `penyakit` (
  `id` int UNSIGNED NOT NULL,
  `kode_penyakit` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `penyakit` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` enum('Show','Deleted') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Show'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `penyakit`
--

INSERT INTO `penyakit` (`id`, `kode_penyakit`, `penyakit`, `created_at`, `updated_at`, `status`) VALUES
(1, 'OPT1', 'Thrips', '2025-01-24 02:42:17', '2025-01-24 02:42:31', 'Show'),
(2, 'OPT2', 'Tungau', '2025-01-24 02:59:30', '2025-01-24 02:59:30', 'Show'),
(3, 'OPT3', 'Aphids', '2025-01-24 02:59:43', '2025-01-24 02:59:43', 'Show'),
(4, 'OPT4', 'Virus Kuning/ Virus Keriting', '2025-01-24 03:00:00', '2025-01-24 03:00:00', 'Show'),
(5, 'OPT5', 'Antraknosa', '2025-01-24 03:00:17', '2025-01-24 03:00:17', 'Show'),
(6, 'OPT6', 'Layu Fusarium', '2025-01-24 03:00:34', '2025-01-24 03:00:34', 'Show'),
(7, 'OPT7', 'Layu Bakteri', '2025-01-24 03:00:47', '2025-01-24 03:00:47', 'Show'),
(8, 'OPT8', 'Ulat Grayak', '2025-01-24 03:00:59', '2025-01-24 03:00:59', 'Show'),
(9, 'OPT9', 'Lalat Buah', '2025-01-24 03:01:10', '2025-01-24 03:01:10', 'Show');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `penyakit`
--
ALTER TABLE `penyakit`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `penyakit`
--
ALTER TABLE `penyakit`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
